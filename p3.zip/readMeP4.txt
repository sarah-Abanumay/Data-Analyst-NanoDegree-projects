Resource :-
https://www.statisticshowto.datasciencecentral.com/probability-and-statistics/z-score/
https://www.statisticshowto.datasciencecentral.com/what-is-an-alpha-level/
https://datascience.stackexchange.com/questions/9362/when-to-use-linear-or-logistic-regression
https://www.youtube.com/watch?v=7FTp9JJ5DfE&feature=youtu.be
https://www.analyticsvidhya.com/blog/2015/08/comprehensive-guide-regression/
http://knowledgetack.com/python/statsmodels/proportions_ztest/
https://pandas.pydata.org/pandas-docs/stable/generated/pandas.DataFrame.duplicated.html
