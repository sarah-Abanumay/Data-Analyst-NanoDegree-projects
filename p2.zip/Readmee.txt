https://stackoverflow.com/questions/15943769/how-do-i-get-the-row-count-of-a-pandas-dataframe
https://seaborn.pydata.org/tutorial.html
https://www.youtube.com/watch?v=huFuakytYWU
https://github.com/deepak525/Investigate_TMDb_Movies/blob/master/investigate_the_TBMb_Dataset.ipynb
