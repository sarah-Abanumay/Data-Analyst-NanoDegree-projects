https://en.wikipedia.org/wiki/Stroop_effect
https://www.thoughtco.com/independent-and-dependent-variables-differences-606115
https://python-graph-gallery.com/33-control-colors-of-boxplot-seaborn/
https://statistics.laerd.com/statistical-guides/dependent-t-test-statistical-guide-2.php
https://statistics.laerd.com/statistical-guides/dependent-t-test-statistical-guide.php
https://www.statisticshowto.datasciencecentral.com/probability-and-statistics/hypothesis-testing/t-score-vs-z-score/
