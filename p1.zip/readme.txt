References:-

https://pythonspot.com/matplotlib-pie-chart/
https://stackoverflow.com/questions/47413325/find-which-city-has-the-highest-number-of-trips
https://stackoverflow.com/questions/12070193/why-is-datetime-strptime-not-working-in-this-simple-example/12070426
https://docs.python.org/3.4/library/datetime.html
https://www.tutorialspoint.com/python/string_len.htm
https://realpython.com/python-histograms/
https://www.youtube.com/watch?v=3Gt6wiXmJp0
https://www.tutorialspoint.com/python/number_round.htm
